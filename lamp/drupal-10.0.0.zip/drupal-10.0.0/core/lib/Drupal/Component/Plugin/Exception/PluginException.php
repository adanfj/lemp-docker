<?php

namespace Drupal\Component\Plugin\Exception;

/**
 * Base class for plugin exceptions.
 */
class PluginException extends \Exception implements ExceptionInterface {}
